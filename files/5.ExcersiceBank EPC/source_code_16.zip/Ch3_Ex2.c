#include<stdio.h>
void main()
{
    int a, b, c, sum;
    printf(�\n Enter any three numbers: �);
    scanf(�%d %d %d�, &a, &b, &c);
    sum = a + b + c;
    printf(�\n Sum = %d�, sum);
}