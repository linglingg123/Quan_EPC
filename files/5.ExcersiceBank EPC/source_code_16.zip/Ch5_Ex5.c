#include <stdio.h>
#include <conio.h>
void main()
{
    clrscr();
    printf(�Result=%d�,(4-2*9/6<=3&&(10*2/4-3>3||(1<5&&8>10))));
}