#include<stdio.h>
main()
{
    int x,y;
    x = 5;
    y = 2;
    printf(�The integers are : %d & %d\n�, x, y);
    printf(�The addition gives : %d\n�, x+y);
    printf(�The subtraction gives : %d\n�, x-y);
    printf(�The multiplication gives : %d\n�, x*y);
    printf(�The division gives : %d\n�, x/y);
    printf(�The modulus gives : %d\n�, x%y);
    getchar();
}