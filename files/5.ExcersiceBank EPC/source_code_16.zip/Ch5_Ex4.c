#include <stdio.h>
#include <conio.h>
void main()
{
    clrscr();
    printf(�40/17*13/3 = %d�,40/17*13/3);
    printf(�\n\n40/17*13/3.0 = %lf�,40/17*13/3.0);
    printf(�\n\n40/17*13.0/3 = %lf�,40/17*13.0/3);
    printf(�\n\n40/17.0*13/3 = %lf�,40/17.0*13/3);
}